// Széri József - 514
// sjim2307

#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello World");

    return 0;
}