#define STR "macro function"

#define add(szam1, szam2) (szam1 + szam2)