#define STR "inline function"

static inline int add(int szam1, int szam2)
{
    return (szam1 + szam2);
}