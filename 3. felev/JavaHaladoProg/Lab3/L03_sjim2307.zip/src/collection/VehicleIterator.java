//Széri József - 514/2
package collection;

import core.Vehicle;

public interface VehicleIterator {
    boolean hasMoreElements();

    Vehicle nextElement();
}
