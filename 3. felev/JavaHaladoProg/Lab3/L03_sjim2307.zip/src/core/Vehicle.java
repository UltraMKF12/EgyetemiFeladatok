//Széri József - 514/2
package core;

public interface Vehicle {
    String toString();

    void numberOfWheels();
}
