//Széri József - 524/2
public class Elso {
    public static void main(String[] args) {
        System.out.println("Hello Jozsef!");
    }
}