package lab8;

// Széri József - 514/2
public interface Plant {
    public double getOxigenAmountPerYear();
    public int getLifeTime();
    public String getRepresentation();
}
