//Széri József - 514/2
public interface Soup{
    public void associateMainDish(MainDish mainDish);
    public String toString();
}
