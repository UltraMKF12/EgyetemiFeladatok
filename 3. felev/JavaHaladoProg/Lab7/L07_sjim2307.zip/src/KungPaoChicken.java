//Széri József - 514/2
public class KungPaoChicken implements MainDish {

    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
