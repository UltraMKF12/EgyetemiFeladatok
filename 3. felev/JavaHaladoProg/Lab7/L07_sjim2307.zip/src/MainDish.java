//Széri József - 514/2
public interface MainDish {
    public String toString();
}
