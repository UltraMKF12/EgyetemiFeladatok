//Széri József - 514/2
public interface Chef {
    public Soup prepareSoup();
    public MainDish prepraeMainDish();
}
