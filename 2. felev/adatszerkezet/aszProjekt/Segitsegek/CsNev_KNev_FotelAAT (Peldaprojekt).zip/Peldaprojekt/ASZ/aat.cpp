///ez a definíciós resz az AAT header állományához

#include "aat.h"