/// ez a header az AAT-hoz
/// deklaracios resz: tipusok, konstansok, fuggveny-fejlecek